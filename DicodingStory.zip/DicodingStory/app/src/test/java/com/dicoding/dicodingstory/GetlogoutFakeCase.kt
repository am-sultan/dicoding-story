package com.dicoding.dicodingstory

import com.dicoding.dicodingstory.usecase.LogoutUseContract

class GetlogoutFakeCase:LogoutUseContract {

     override suspend fun invoke() = Unit
}