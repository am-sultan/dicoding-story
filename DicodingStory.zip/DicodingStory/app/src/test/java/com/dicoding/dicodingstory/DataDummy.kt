package com.dicoding.dicodingstory

import com.dicoding.dicodingstory.response.StoryResponse

object DataDummy {

    fun generateDummyStoryResponse(): List<StoryResponse> {
        val items: MutableList<StoryResponse> = arrayListOf()
        for (i in 0..100) {
            val story = StoryResponse(
                i.toString(),
                "createdAt + $1",
                "description + $1",
                0.0,
                0.0,
                "name $1",
                "photoUrl $1"
            )
            items.add(story)
        }
        return items
    }
}