package com.dicoding.dicodingstory

import androidx.paging.PagingData
import com.dicoding.dicodingstory.entity.StoryEntity
import com.dicoding.dicodingstory.response.StoryResponse
import com.dicoding.dicodingstory.usecase.GetStoriesContract
import kotlinx.coroutines.flow.Flow

class GetStoriesFakeCase:GetStoriesContract {

    val fakeStoriesflow = FlowTestUtil<PagingData<StoryResponse>>()

    override fun invoke(): Flow<PagingData<StoryResponse>> = fakeStoriesflow.flow
}