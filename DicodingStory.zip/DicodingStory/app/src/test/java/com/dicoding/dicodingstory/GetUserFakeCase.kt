package com.dicoding.dicodingstory

import com.dicoding.dicodingstory.entity.UserEntity
import com.dicoding.dicodingstory.response.StoryResponse
import com.dicoding.dicodingstory.usecase.GetUserContract
import kotlinx.coroutines.flow.Flow

class GetUserFakeCase:GetUserContract {

    val fakeUserflow = FlowTestUtil<StoryResponse>()

     override fun invoke(): Flow<StoryResponse> = fakeUserflow.flow
}