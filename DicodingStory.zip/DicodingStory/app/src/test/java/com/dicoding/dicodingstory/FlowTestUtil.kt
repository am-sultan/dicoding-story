package com.dicoding.dicodingstory

import kotlinx.coroutines.flow.MutableSharedFlow

class FlowTestUtil<T> {
    val flow: MutableSharedFlow<T> = MutableSharedFlow()

    suspend fun emit(value: T) = flow.emit(value)
}