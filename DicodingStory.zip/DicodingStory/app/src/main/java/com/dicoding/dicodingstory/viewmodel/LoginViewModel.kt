package com.dicoding.dicodingstory.viewmodel

import androidx.lifecycle.*
import com.dicoding.dicodingstory.usecase.LoginUseCase
import com.dicoding.dicodingstory.viewstate.LoginViewState
import kotlinx.coroutines.flow.*

class LoginViewModel (private val loginUseCase: LoginUseCase):ViewModel() {

    private val _loginstate = MutableStateFlow(LoginViewState())
    val loginState = _loginstate.asStateFlow()

    fun login(email: String, password: String) {
        loginUseCase(email, password).onEach {result ->
        _loginstate.update {
            it.copy(verifUser = result)
            }
        }.launchIn(viewModelScope)
    }

    class Factory(private val loginUseCase: LoginUseCase): ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
                return LoginViewModel(loginUseCase) as T
            }
            error("Unknown ViewModel class: $modelClass")
        }
    }
}