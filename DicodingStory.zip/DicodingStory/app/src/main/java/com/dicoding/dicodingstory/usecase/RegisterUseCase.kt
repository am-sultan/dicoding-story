package com.dicoding.dicodingstory.usecase

import com.dicoding.dicodingstory.utility.ResultState
import com.dicoding.dicodingstory.repository.AuthenticationRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow

class RegisterUseCase(private val authenticationRepository: AuthenticationRepository) {
    operator fun invoke(name: String, email: String, password: String): Flow<ResultState<String>> = flow {
       emit(ResultState.Loading())
       authenticationRepository.register(email, password, name).catch {
           emit(ResultState.Error(it.message.toString()))
       }.collect { result ->
           if (result.error) {
               emit(ResultState.Error(result.message))
           } else {
               emit(ResultState.Success(result.message))
           }
       }
    }
}
