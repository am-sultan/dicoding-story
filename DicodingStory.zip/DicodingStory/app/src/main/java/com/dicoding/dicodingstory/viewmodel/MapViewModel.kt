package com.dicoding.dicodingstory.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dicoding.dicodingstory.usecase.GetStoriesLocationCase
import com.dicoding.dicodingstory.viewstate.MapViewState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MapViewModel(private val getStoriesLocationCase: GetStoriesLocationCase): ViewModel() {
    private val _mapState = MutableStateFlow(MapViewState())
    val mapState = _mapState.asStateFlow()

    fun getStoryLocation() {
        viewModelScope.launch {
            getStoriesLocationCase().collect { location ->
                _mapState.update {
                    it.copy(resultMapStories = location)
                }
            }
        }
    }

    class Factory(private val getStoriesLocationCase: GetStoriesLocationCase): ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MapViewModel::class.java)) {
                return MapViewModel(getStoriesLocationCase) as T
            }
            error("unknown ViewModel class: $modelClass")
        }
    }
}
