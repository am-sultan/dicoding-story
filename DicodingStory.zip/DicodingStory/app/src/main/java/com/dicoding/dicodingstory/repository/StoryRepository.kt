package com.dicoding.dicodingstory.repository

import androidx.paging.PagingData
import com.dicoding.dicodingstory.response.DetailResponse
import com.dicoding.dicodingstory.response.ListResponse
import com.dicoding.dicodingstory.response.RegisterResponse
import com.dicoding.dicodingstory.response.StoryResponse
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.flow.Flow
import java.io.File

interface StoryRepository {
    fun getStories(): Flow<PagingData<StoryResponse>>
    fun getStoriesWithLocation(id: Int): Flow<ListResponse>
    fun getStory(id: String): Flow<DetailResponse>
    fun addStory(file: File, description: String, latLng: LatLng?): Flow<RegisterResponse>
}