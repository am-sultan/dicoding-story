package com.dicoding.dicodingstory.Paging

import androidx.paging.PagingData
import androidx.paging.map
import com.dicoding.dicodingstory.entity.StoryEntity
import com.dicoding.dicodingstory.response.StoryResponse

fun StoryResponse.map() = let { story ->
    StoryEntity(
        id = story.id,
        name = story.name,
        description = story.description,
        photoUrl = story.photoUrl,
        lat = story.lat,
        lng = story.lon
    )
}

fun List<StoryResponse>.map() = map { story ->
    StoryEntity(
        id = story.id,
        name = story.name,
        description = story.description,
        photoUrl = story.photoUrl,
        lat = story.lat,
        lng = story.lon
    )
}

fun PagingData<StoryResponse>.map() = map { story ->
    StoryResponse(
        id = story.id,
        name = story.name,
        description = story.description,
        photoUrl = story.photoUrl,
        lat = story.lat,
        createdAt = story.createdAt,
        lon = story.lon
    )
}