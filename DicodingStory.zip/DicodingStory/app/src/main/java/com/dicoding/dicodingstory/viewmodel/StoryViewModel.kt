package com.dicoding.dicodingstory.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.paging.cachedIn
import com.dicoding.dicodingstory.usecase.*
import com.dicoding.dicodingstory.viewstate.StoryViewState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class StoryViewModel (private val getStoriesCase: GetStoriesContract, private val getUserCase: GetUserContract, private val logoutUseCase: LogoutUseContract): ViewModel() {
    private val _storyState = MutableStateFlow(StoryViewState())
    val storystate = _storyState.asStateFlow()

    fun getStory() {
        viewModelScope.launch {
            getStoriesCase().cachedIn(viewModelScope).collect { story ->
                _storyState.update {
                    it.copy(resultStories = story)
                }
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            logoutUseCase()
        }
    }

    fun getUser() {
        viewModelScope.launch {
            getUserCase().collect{ user->
                _storyState.update {
                    it.copy(username = user.name)
                }
            }
        }
    }

    class Factory(private val getStoriesCase: GetStoriesCase, private val getUserCase: GetUserCase, private val logoutUseCase: LogoutUseCase): ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(StoryViewModel::class.java)) {
                return  StoryViewModel(getStoriesCase, getUserCase, logoutUseCase) as T
            }
            error("unknown viewModel class: $modelClass")
        }
    }

}