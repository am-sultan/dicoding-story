package com.dicoding.dicodingstory.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.bumptech.glide.Glide
import com.dicoding.dicodingstory.Locator
import com.dicoding.dicodingstory.databinding.ActivityStoryDetailBinding
import com.dicoding.dicodingstory.entity.StoryEntity
import com.dicoding.dicodingstory.utility.ResultState
import com.dicoding.dicodingstory.utility.launchAndCollectIn
import com.dicoding.dicodingstory.viewmodel.StoryDetailViewModel

class StoryDetailActivity : AppCompatActivity() {

    private lateinit var storyDetailBinding: ActivityStoryDetailBinding
    private val viewModel by viewModels<StoryDetailViewModel>(factoryProducer ={Locator.storyDetailViewModelFactory})

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        storyDetailBinding = ActivityStoryDetailBinding.inflate(layoutInflater)
        setContentView(storyDetailBinding.root)

        intent.getStringExtra(EXTRA_STORY_ID)?.let {
            viewModel.getStoryDetail(it)
        }

        viewModel.storyDetailViewState.launchAndCollectIn(this) { state ->
            when(state.resultStory) {
                is ResultState.Success<StoryEntity> -> {
                    showLoading(false)
                    state.resultStory.data?.let {
                        storyDetailBinding.tvDetailName.text = it.name
                        storyDetailBinding.tvDetailDesc.text = it.description
                        Glide.with(this@StoryDetailActivity)
                            .load(it.photoUrl)
                            .into(storyDetailBinding.detailPhoto)
                    }
                }

                is ResultState.Loading -> showLoading(true)
                is ResultState.Error -> {
                    showLoading(false)
                    Toast.makeText(this@StoryDetailActivity, state.resultStory.message, Toast.LENGTH_SHORT).show()
                }
                else -> Unit
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        storyDetailBinding.progressBarStoryDetail.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val EXTRA_STORY_ID = "STORY_ID"
    }
}