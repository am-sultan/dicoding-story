package com.dicoding.dicodingstory.response

data class DetailResponse (
    val error: Boolean,
    val message: String,
    val story: StoryResponse
    )