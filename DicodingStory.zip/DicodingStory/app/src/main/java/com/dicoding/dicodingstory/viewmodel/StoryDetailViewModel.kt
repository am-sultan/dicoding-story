package com.dicoding.dicodingstory.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dicoding.dicodingstory.usecase.GetStoriesDetailCase
import com.dicoding.dicodingstory.viewstate.StoryDetailViewState
import kotlinx.coroutines.flow.*

class StoryDetailViewModel(private val getStoriesDetailCase: GetStoriesDetailCase): ViewModel() {

    private val _storyDetailViewState = MutableStateFlow(StoryDetailViewState())
    val storyDetailViewState get() = _storyDetailViewState.asStateFlow()

    fun getStoryDetail(id: String) {
        getStoriesDetailCase(id).onEach { result ->
            _storyDetailViewState.update {
                it.copy(resultStory = result)
            }
        }.launchIn(viewModelScope)
    }

    class Factory(private val getStoriesDetailCase: GetStoriesDetailCase): ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(StoryDetailViewModel::class.java)) {
                return StoryDetailViewModel(getStoriesDetailCase) as T
            }
            error("unknown ViewModel class: $modelClass")
        }
    }
}