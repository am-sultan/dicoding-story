package com.dicoding.dicodingstory.activity

import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import androidx.activity.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.dicodingstory.Locator
import com.dicoding.dicodingstory.adapter.LoadingStateAdapter
import com.dicoding.dicodingstory.adapter.StoryAdapter
import com.dicoding.dicodingstory.databinding.ActivityStoryBinding
import com.dicoding.dicodingstory.utility.launchAndCollectIn
import com.dicoding.dicodingstory.viewmodel.StoryViewModel

class StoryActivity : AppCompatActivity() {

    private lateinit var storyBinding: ActivityStoryBinding
    private val viewModel by viewModels<StoryViewModel>(factoryProducer = {Locator.storyViewModelFactory})
    private val adapter by lazy { StoryAdapter() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        storyBinding = ActivityStoryBinding.inflate(layoutInflater)
        setContentView(storyBinding.root)

        initAdapter()
        viewModel.storystate.launchAndCollectIn(this) {
            adapter.submitData(lifecycle, it.resultStories)
            storyBinding.tvUsername.text = it.username
            }

        storyBinding.btnAddStory.setOnClickListener {
            startActivity(Intent(this@StoryActivity, AddStoryActivity::class.java))
        }

        storyBinding.logout.setOnClickListener {
            viewModel.logout()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        storyBinding.languageChange.setOnClickListener {
            startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
        }

        storyBinding.openMap.setOnClickListener {
            startActivity(Intent(this, MapsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.getStory()
        viewModel.getUser()
    }

    private fun initAdapter() {
        storyBinding.rvStory.adapter = adapter
        storyBinding.rvStory.adapter = adapter.withLoadStateFooter(
            footer = LoadingStateAdapter {
                adapter.retry()
            }
        )

        if (applicationContext.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
           storyBinding.rvStory.layoutManager = GridLayoutManager(this,2)
        } else storyBinding.rvStory.layoutManager = LinearLayoutManager(this)
    }

}