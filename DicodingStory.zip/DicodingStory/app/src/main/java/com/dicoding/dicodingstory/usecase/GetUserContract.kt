package com.dicoding.dicodingstory.usecase

import com.dicoding.dicodingstory.entity.UserEntity
import com.dicoding.dicodingstory.response.StoryResponse
import kotlinx.coroutines.flow.Flow

interface GetUserContract {
    operator fun invoke(): Flow<StoryResponse>
}