package com.dicoding.dicodingstory.Paging

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface KeysDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(remoteKeys: List<RemoteKeys>)

    @Query("SELECT * FROM Keys WHERE id = :id")
    suspend fun getKeysId(id: String): RemoteKeys?

    @Query("DELETE FROM Keys")
    suspend fun deleteKeys()
}