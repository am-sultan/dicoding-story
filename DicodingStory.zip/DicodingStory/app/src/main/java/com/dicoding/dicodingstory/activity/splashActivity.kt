package com.dicoding.dicodingstory.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import com.dicoding.dicodingstory.Locator
import com.dicoding.dicodingstory.databinding.ActivitySplashBinding
import com.dicoding.dicodingstory.utility.ResultState
import com.dicoding.dicodingstory.utility.launchAndCollectIn
import com.dicoding.dicodingstory.viewmodel.splashViewModel

class splashActivity : AppCompatActivity() {

    private lateinit var splashBinding: ActivitySplashBinding
    private val viewModel by viewModels<splashViewModel>(factoryProducer = {Locator.splashViewModelFactory})

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        splashBinding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(splashBinding.root)

        viewModel.splashState.launchAndCollectIn(this) {
            if (it.resultIsLoggedIn is ResultState.Success) {
                if (it.resultIsLoggedIn.data == true) {
                    startActivity(Intent(this@splashActivity, StoryActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                    finish()
                } else {
                    startActivity(Intent(this@splashActivity, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                    finish()
                }
            }
        }
    }
}