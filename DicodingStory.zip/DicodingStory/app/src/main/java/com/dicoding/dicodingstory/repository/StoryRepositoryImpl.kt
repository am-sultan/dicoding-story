package com.dicoding.dicodingstory.repository

import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.dicoding.dicodingstory.API.ApiService
import com.dicoding.dicodingstory.Paging.StoryPagingDatabase
import com.dicoding.dicodingstory.Paging.StoryRemoteMediator
import com.dicoding.dicodingstory.response.StoryResponse
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class StoryRepositoryImpl(private val storyPagingDatabase: StoryPagingDatabase,private val api: ApiService) : StoryRepository {

    override fun getStories(): Flow<PagingData<StoryResponse>> {
        @OptIn(ExperimentalPagingApi::class) return  Pager(
            config = PagingConfig(
                pageSize = 5
            ), remoteMediator = StoryRemoteMediator(storyPagingDatabase, api),
            pagingSourceFactory = {
                storyPagingDatabase.StoryPagingsDao().getAllStory()
            }
        ).flow
    }

    override fun getStoriesWithLocation(id: Int) = flow {
        emit(api.storiesWithLocation(id))
    }.flowOn(Dispatchers.IO)

    override fun getStory(id: String) = flow {
        emit(api.storyDetail(id))
    }.flowOn(Dispatchers.IO)

    override fun addStory(file: File, description: String, latLng: LatLng?) = flow{
        val requestBody = MultipartBody.Part.createFormData(
            "photo", file.name, file.asRequestBody("image/jpeg".toMediaTypeOrNull())
        )
        emit(api.addStory(requestBody,
            description.toRequestBody("text/plain".toMediaType()),
            latLng?.latitude?.toFloat(),
            latLng?.longitude?.toFloat()
        ))
    }.flowOn(Dispatchers.IO)
}