package com.dicoding.dicodingstory.usecase

import com.dicoding.dicodingstory.entity.UserEntity
import com.dicoding.dicodingstory.repository.UserPreferenceRepository
import kotlinx.coroutines.flow.Flow

class GetUserCase(private val userPreferenceRepository: UserPreferenceRepository):GetUserContract {
    override operator fun invoke(): Flow<UserEntity> = userPreferenceRepository.dataUser
}
