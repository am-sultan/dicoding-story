package com.dicoding.dicodingstory.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dicoding.dicodingstory.usecase.AddStoryCase
import com.dicoding.dicodingstory.viewstate.AddStoryViewState
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.flow.*
import java.io.File

class AddStoryViewModel(private val addStoryCase: AddStoryCase): ViewModel() {

    private val _addStoryState = MutableStateFlow(AddStoryViewState())
    val addStoryState = _addStoryState.asStateFlow()

    fun addStory(file: File, desc: String, latLng: LatLng?) {
        addStoryCase(file, desc, latLng).onEach { result ->
            _addStoryState.update {
                it.copy(resultAddStory = result)
            }
        }.launchIn(viewModelScope)
    }

    class Factory(private val addStoryCase: AddStoryCase): ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(AddStoryViewModel::class.java)) {
                return AddStoryViewModel(addStoryCase) as T
            }
            error("unknown ViewModel class: $modelClass")
        }
    }
}