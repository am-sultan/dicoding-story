package com.dicoding.dicodingstory

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import com.dicoding.dicodingstory.API.Retrofit
import com.dicoding.dicodingstory.Paging.StoryPagingDatabase
import com.dicoding.dicodingstory.repository.AuthRepositoryImpl
import com.dicoding.dicodingstory.repository.StoryRepositoryImpl
import com.dicoding.dicodingstory.repository.UserPreferenceImpl
import com.dicoding.dicodingstory.usecase.*
import com.dicoding.dicodingstory.viewmodel.*

object Locator {
    private var application: Application? = null

    private inline val requireApplication
        get() = application ?: error("Missing call: initWith(application)")

    fun initWith(application: Application) {
        this.application = application
    }

    private val Context.datastore by preferencesDataStore(name = "user_preferences")

    val loginViewModelFactory
        get() = LoginViewModel.Factory(
            loginUseCase = loginUseCase
        )

    val registerViewModelFactory
        get() = RegisterViewModel.Factory(
            registerUseCase = registerUseCase
        )

    val storyViewModelFactory
        get() = StoryViewModel.Factory(
            getStoriesCase = getStoriesCase,
            getUserCase = getUserCase,
            logoutUseCase =  logoutUseCase
        )

    val storyDetailViewModelFactory
        get() = StoryDetailViewModel.Factory(
            getStoriesDetailCase = getStoryDetailCase
        )

    val addStoryViewModelFactory
        get() = AddStoryViewModel.Factory(
            addStoryCase = addStoryCase
        )

    val splashViewModelFactory
        get() = splashViewModel.Factory(
            getUserCase = getUserCase
        )

    val mapViewMdelFactory
        get() = MapViewModel.Factory(
            getStoriesLocationCase = getStoriesLocationCase
        )


    private val loginUseCase get() = LoginUseCase(userPreferencesRepository, authRepository)
    private val registerUseCase get() = RegisterUseCase(authRepository)
    private val getUserCase get() = GetUserCase(userPreferencesRepository)
    private val getStoriesCase get() = GetStoriesCase(storyRepository)
    private val logoutUseCase get() = LogoutUseCase(userPreferencesRepository)
    private val getStoryDetailCase get() = GetStoriesDetailCase(storyRepository)
    private val addStoryCase get() = AddStoryCase(storyRepository)
    private val getStoriesLocationCase get() = GetStoriesLocationCase(storyRepository)

    private val userPreferencesRepository by lazy {
        UserPreferenceImpl(requireApplication.datastore)
    }

    private val authRepository by lazy {
        AuthRepositoryImpl(Retrofit(requireApplication.datastore).apiService)
    }

    private val storyRepository by lazy {
        StoryRepositoryImpl(
            StoryPagingDatabase.getDatabase(requireApplication),
            Retrofit(requireApplication.datastore).apiService
        )
    }
}