package com.dicoding.dicodingstory.viewstate

import com.dicoding.dicodingstory.utility.ResultState

data class LoginViewState(
    val verifUser: ResultState<String> = ResultState.Idle()
)
