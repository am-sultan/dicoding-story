package com.dicoding.dicodingstory.repository

import com.dicoding.dicodingstory.response.LoginResponse
import com.dicoding.dicodingstory.response.RegisterResponse
import kotlinx.coroutines.flow.Flow

interface AuthenticationRepository {
    fun register(email: String, password: String, name: String): Flow<RegisterResponse>
    fun login(email: String, password: String): Flow<LoginResponse>
}