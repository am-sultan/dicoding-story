package com.dicoding.dicodingstory.usecase

import com.dicoding.dicodingstory.Paging.map
import com.dicoding.dicodingstory.entity.StoryEntity
import com.dicoding.dicodingstory.repository.StoryRepository
import com.dicoding.dicodingstory.utility.ResultState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

class GetStoriesLocationCase(private val storyRepository: StoryRepository) {

    operator fun invoke(): Flow<ResultState<List<StoryEntity>>> = flow {
        emit(ResultState.Loading())
        storyRepository.getStoriesWithLocation(1).map {
            it.listStory.map()
        }.catch {
            emit(ResultState.Error(message = it.message.toString()))
        }.collect {
            emit(ResultState.Success(it))
        }
    }
}