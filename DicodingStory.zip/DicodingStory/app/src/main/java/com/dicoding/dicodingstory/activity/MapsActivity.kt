package com.dicoding.dicodingstory.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.dicoding.dicodingstory.Locator
import com.dicoding.dicodingstory.R
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.dicoding.dicodingstory.databinding.ActivityMapsBinding
import com.dicoding.dicodingstory.utility.ResultState
import com.dicoding.dicodingstory.utility.launchAndCollectIn
import com.dicoding.dicodingstory.viewmodel.MapViewModel
import com.google.android.gms.maps.model.MapStyleOptions


class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private val viewModel by viewModels<MapViewModel>(factoryProducer = { Locator.mapViewMdelFactory })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        viewModel.getStoryLocation()
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this,R.raw.gmap_style))

        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isIndoorLevelPickerEnabled = true
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = true
        storyMarker()
    }

    private fun storyMarker() {
        viewModel.mapState.launchAndCollectIn(this) {
            when (it.resultMapStories) {
               is ResultState.Success -> {
                   showLoading(false)
                   it.resultMapStories.data?.forEach { story ->
                       val position = LatLng(story.lat, story.lng)
                       mMap.addMarker(MarkerOptions().position(position).title(story.name))
                       mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(position, 5f))
                   }
               }

                is ResultState.Error -> {
                    showLoading(false)
                    Toast.makeText(this@MapsActivity,it.resultMapStories.message, Toast.LENGTH_SHORT).show()
                }
                is ResultState.Loading -> {
                    showLoading(true)
                }

                else -> Unit
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBarMap.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}