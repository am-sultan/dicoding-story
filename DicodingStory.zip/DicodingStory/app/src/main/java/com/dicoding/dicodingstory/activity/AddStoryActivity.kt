package com.dicoding.dicodingstory.activity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.location.Location
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import com.dicoding.dicodingstory.Locator
import com.dicoding.dicodingstory.R
import com.dicoding.dicodingstory.databinding.ActivityAddStoryBinding
import com.dicoding.dicodingstory.utility.*
import com.dicoding.dicodingstory.viewmodel.AddStoryViewModel
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.LatLng
import java.io.File

class AddStoryActivity : AppCompatActivity() {

    private lateinit var addStoryBinding: ActivityAddStoryBinding
    private lateinit var currentPhotoPath: String
    private val viewModel by viewModels<AddStoryViewModel>(factoryProducer = {Locator.addStoryViewModelFactory})
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var getFile: File? = null
    private var latLng: LatLng? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        addStoryBinding = ActivityAddStoryBinding.inflate(layoutInflater)
        setContentView(addStoryBinding.root)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (!REQUIRED_PERMISSIONS.checkPermissionsGranted(baseContext)) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }

        addStoryBinding.buttonCamera.setOnClickListener {
            startTakePhoto()
        }

        addStoryBinding.buttonGallery.setOnClickListener {
            openGallery()
        }

        addStoryBinding.switchAddLocation.setOnCheckedChangeListener {_, isChecked ->
            if (isChecked) {
                getMyLastLocation()
            }
        }

        addStoryBinding.uploadStory.setOnClickListener {
            if (getFile != null) {
                getFile?.let {
                    viewModel.addStory(it.fileImageReducer(), addStoryBinding.edtDesc.text.toString(),latLng)
                }
            } else {
                Toast.makeText(this, getString(R.string.choose_image), Toast.LENGTH_SHORT).show()
            }
        }

        viewModel.addStoryState.launchAndCollectIn(this) {state ->
            when(state.resultAddStory) {
                is ResultState.Success<String> -> {
                    showLoading(false)
                    Toast.makeText(this@AddStoryActivity, getString(R.string.add_success), Toast.LENGTH_SHORT).show()
                    finish()
                }
                is ResultState.Loading -> showLoading(true)
                is ResultState.Error -> {
                    showLoading(false)
                    Toast.makeText(this@AddStoryActivity, state.resultAddStory.message, Toast.LENGTH_SHORT).show()
                }
                else -> Unit
            }
        }

    }


    private fun getMyLastLocation() {
        if (REQUIRED_LOCATION_PERMISSIONS.checkPermissionsGranted(baseContext)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
              if (location != null) {
                  latLng = LatLng(location.latitude, location.longitude)
              } else {
                  addStoryBinding.switchAddLocation.isEnabled = false
                  Toast.makeText(this ,getString(R.string.no_location), Toast.LENGTH_SHORT).show()
              }
            }
        } else {
            requestPermissionLauncher.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ))
        }
    }

    private fun startTakePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.resolveActivity(packageManager)

        createCustomTempFile(application).also {
            val photoUri: Uri = FileProvider.getUriForFile(this@AddStoryActivity,packageName,it)
            currentPhotoPath = it.absolutePath
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
            launcherIntentCamera.launch(intent)
        }
    }

    private fun openGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, "Choose a Picture From Gallery")
        launcherOpenGallery.launch(chooser)
    }

    private val launcherIntentCamera = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) {
            val ourFile = File(currentPhotoPath)
            getFile = ourFile
            val result = BitmapFactory.decodeFile(ourFile.path)
           addStoryBinding.imageAddPhoto.setImageBitmap(result)
        }
    }

    private val launcherOpenGallery = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImage: Uri = result.data?.data as Uri
            val ourFile = selectedImage.uriToFile(this@AddStoryActivity)
            getFile = ourFile
            addStoryBinding.imageAddPhoto.setImageURI(selectedImage)
        }
    }

    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        when {
            permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false -> {
                getMyLastLocation()
            }
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false -> {
                getMyLastLocation()
            }
            else -> {

            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS)
            if (!REQUIRED_PERMISSIONS.checkPermissionsGranted(baseContext)) {
                Toast.makeText(this, getString(R.string.permission_denied), Toast.LENGTH_SHORT).show()
                finish()
            } else if (requestCode == REQUEST_LOCATION_PERMISSIONS) {
                if (!REQUIRED_LOCATION_PERMISSIONS.checkPermissionsGranted(baseContext))
                    Toast.makeText(this,getString(R.string.permission_denied), Toast.LENGTH_SHORT).show()
                finish()
            }
    }

    private fun showLoading(isLoading: Boolean) {
        addStoryBinding.progressBarAddStory.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private val REQUIRED_LOCATION_PERMISSIONS = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        private const val REQUEST_CODE_PERMISSIONS = 10
        private const val REQUEST_LOCATION_PERMISSIONS = 11
    }
}