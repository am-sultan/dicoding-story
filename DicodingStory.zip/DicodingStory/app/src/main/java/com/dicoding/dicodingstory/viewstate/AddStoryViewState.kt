package com.dicoding.dicodingstory.viewstate

import com.dicoding.dicodingstory.utility.ResultState

data class AddStoryViewState (
    val resultAddStory: ResultState<String> = ResultState.Idle()
)