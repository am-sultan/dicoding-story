package com.dicoding.dicodingstory.viewstate

import com.dicoding.dicodingstory.utility.ResultState

data class splashViewState (
    val resultIsLoggedIn: ResultState<Boolean> = ResultState.Idle()
)