package com.dicoding.dicodingstory.repository

import com.dicoding.dicodingstory.API.ApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class AuthRepositoryImpl(private val apiService: ApiService): AuthenticationRepository {

    override fun register(email: String, password: String, name: String) = flow {
      emit(
          apiService.register(
              hashMapOf(
                  Pair("name", name),
                  Pair("password", password),
                  Pair("email", email)
              )
          )
      )
    }.flowOn(Dispatchers.IO)

    override fun login(email: String, password: String) = flow {
        emit(
            apiService.login(
                hashMapOf(
                    Pair("password", password),
                    Pair("email", email)
                )
            )
        )
    }.flowOn(Dispatchers.IO)
}