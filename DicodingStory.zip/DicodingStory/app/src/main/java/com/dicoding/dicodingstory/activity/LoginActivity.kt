package com.dicoding.dicodingstory.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.dicoding.dicodingstory.Locator
import com.dicoding.dicodingstory.databinding.ActivityLoginBinding
import com.dicoding.dicodingstory.utility.ResultState
import com.dicoding.dicodingstory.utility.launchAndCollectIn
import com.dicoding.dicodingstory.viewmodel.LoginViewModel

class LoginActivity : AppCompatActivity() {

    private lateinit var loginBinding: ActivityLoginBinding
    private val viewModel by viewModels<LoginViewModel>(factoryProducer = {Locator.loginViewModelFactory})

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loginBinding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(loginBinding.root)

        loginStart()
        viewModel.loginState.launchAndCollectIn(this) { state ->
            when(state.verifUser) {
                is ResultState.Success<String> -> {
                    showLoading(false)
                        showLoading(false)
                        startActivity(Intent(this@LoginActivity,StoryActivity::class.java))
                        finish()
                }
                is ResultState.Loading -> showLoading(true)
                is ResultState.Error -> {
                        showLoading(false)
                        Toast.makeText(this@LoginActivity, state.verifUser.message, Toast.LENGTH_SHORT).show()
                }

                else -> Unit
            }
        }

        loginBinding.btnLogin.setOnClickListener{
            viewModel.login(
                email = loginBinding.edtEmail.text.toString(),
                password = loginBinding.edtPassword.text.toString()
            )
        }
        loginBinding.tvRegister.setOnClickListener{
        startActivity(Intent(this,RegisterActivity::class.java))
        }

        loginBinding.edtPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                loginStart()
            }
            override fun afterTextChanged(s: Editable) {
            }
        })

    }

    private fun loginStart() {
        val validPassword = loginBinding.edtPassword.text.toString()
        loginBinding.btnLogin.isEnabled = !TextUtils.isEmpty(validPassword) && validPassword.length >= 8

    }

    private fun showLoading(isLoading: Boolean) {
        loginBinding.progressBarLogin.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}
