package com.dicoding.dicodingstory.Paging

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.dicoding.dicodingstory.response.StoryResponse

@Dao
interface PagingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: List<StoryResponse>)

    @Query("SELECT * FROM Stories")
    fun getAllStory(): PagingSource<Int, StoryResponse>

    @Query("DELETE FROM Stories")
    suspend fun deleteAllStory()
}