package com.dicoding.dicodingstory.viewstate

import com.dicoding.dicodingstory.utility.ResultState

data class RegisterViewState(
    val resultRegisterUser: ResultState<String> = ResultState.Idle()
)
