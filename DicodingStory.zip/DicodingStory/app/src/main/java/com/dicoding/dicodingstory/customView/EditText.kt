package com.dicoding.dicodingstory.customView

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import com.dicoding.dicodingstory.R

class EditText : AppCompatEditText {
    private lateinit var edtBackground: Drawable
    private lateinit var edtErrorBackground: Drawable
    private var isError = false

    constructor(context: Context): super(context) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet): super(context,attrs) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init()
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        background = if (isError) edtErrorBackground else edtBackground
        addTextChangedListener(onTextChanged = { text, _, _, _ ->
            if (!TextUtils.isEmpty(text) && text.toString().length < 8 && compoundDrawables[DRAWABLE_RIGHT] != null) {
                error = resources.getString(R.string.password_Min_Char)
                isError = true
            } else {
                error = null
                isError = false
            }
        })
    }

    private fun init() {
        edtBackground = ContextCompat.getDrawable(context, R.drawable.bg_edt) as Drawable
        edtErrorBackground = ContextCompat.getDrawable(context, R.drawable.bg_edt_error) as Drawable

        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

            }
            override fun afterTextChanged(s: Editable) {

            }
        })
    }

    companion object {
        const val DRAWABLE_RIGHT = 2
    }
}