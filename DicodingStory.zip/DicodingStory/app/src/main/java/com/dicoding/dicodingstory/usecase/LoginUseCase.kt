package com.dicoding.dicodingstory.usecase

import com.dicoding.dicodingstory.utility.ResultState
import com.dicoding.dicodingstory.entity.UserEntity
import com.dicoding.dicodingstory.repository.AuthenticationRepository
import com.dicoding.dicodingstory.repository.UserPreferenceRepository
import kotlinx.coroutines.flow.*

class LoginUseCase (
    private val userPreferencesRepository: UserPreferenceRepository,
    private val authenticationRepository: AuthenticationRepository,
        ) {
    operator fun invoke(email: String, password: String): Flow<ResultState<String>> = flow {
        emit(ResultState.Loading())
        authenticationRepository.login(email, password).catch {
            emit(ResultState.Error(it.message.toString()))
        }.collect { result ->
            if (result.error) {
                emit(ResultState.Error(result.message))
            } else {
                result.loginResult.let {
                    userPreferencesRepository.saveUser(
                        UserEntity(
                            it.userId,
                            it.name,
                            it.token
                        )
                    )
                }
                emit(ResultState.Success(result.message))
            }
        }
    }
}
