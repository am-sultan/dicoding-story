package com.dicoding.dicodingstory.usecase

interface LogoutUseContract {
    suspend operator fun invoke()
}