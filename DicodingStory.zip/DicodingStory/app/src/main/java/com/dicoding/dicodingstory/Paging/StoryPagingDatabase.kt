package com.dicoding.dicodingstory.Paging

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.dicoding.dicodingstory.response.StoryResponse


@Database(
    entities = [StoryResponse::class, RemoteKeys::class],
    version = 2,
    exportSchema = false
)
abstract class StoryPagingDatabase: RoomDatabase() {
    abstract fun StoryPagingsDao(): PagingDao
    abstract fun keysDao(): KeysDao

    companion object{
        @Volatile
        private var INSTANCE: StoryPagingDatabase? = null

        @JvmStatic
        fun getDatabase(context: Context): StoryPagingDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    StoryPagingDatabase::class.java,"story_paging_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}