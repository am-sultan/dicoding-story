package com.dicoding.dicodingstory.viewstate

import androidx.paging.PagingData
import com.dicoding.dicodingstory.entity.StoryEntity


data class StoryViewState (
    val resultStories: PagingData<StoryEntity> = PagingData.empty(),
    val username: String = " "
        )