package com.dicoding.dicodingstory.entity

data class UserEntity (
    val id: String,
    val name: String,
    val token: String,
)