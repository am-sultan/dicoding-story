package com.dicoding.dicodingstory.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dicoding.dicodingstory.usecase.GetUserCase
import com.dicoding.dicodingstory.utility.ResultState
import com.dicoding.dicodingstory.viewstate.splashViewState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class splashViewModel(private val getUserCase: GetUserCase): ViewModel() {

    private val _splashState = MutableStateFlow(splashViewState())
    val splashState = _splashState.asStateFlow()

    init {
        getIsLoggedIn()
    }

    private fun getIsLoggedIn() {
        viewModelScope.launch {
            getUserCase().collect { user ->
                delay(5000)
                _splashState.update {
                    it.copy(resultIsLoggedIn = ResultState.Success(user.token.isNotEmpty()))
                }
            }
        }
    }

    class Factory(private val getUserCase: GetUserCase): ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(splashViewModel::class.java)) {
                return splashViewModel(getUserCase) as T
            }
            error("unknown ViewModel class: $modelClass")
        }
    }
}