package com.dicoding.dicodingstory.response

data class LoginResponse (
    val error: Boolean,
    val loginResult: LoginResult,
    val message: String
    )

data class LoginResult(
    val userId: String,
    val name: String,
    val token: String,
)