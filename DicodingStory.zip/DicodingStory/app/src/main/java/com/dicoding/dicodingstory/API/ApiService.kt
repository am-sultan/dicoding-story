package com.dicoding.dicodingstory.API

import com.dicoding.dicodingstory.response.DetailResponse
import com.dicoding.dicodingstory.response.ListResponse
import com.dicoding.dicodingstory.response.LoginResponse
import com.dicoding.dicodingstory.response.RegisterResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.*

interface ApiService {
    @POST("register")
    suspend fun register(
        @Body requestBody: HashMap<String, String>
    ): RegisterResponse

    @POST("login")
    suspend fun login(
        @Body requestBody: HashMap<String, String>
    ): LoginResponse

    @GET("stories")
    suspend fun stories(
        @Query("page") page: Int,
        @Query("size") size: Int
    ): ListResponse

    @GET("stories")
    suspend fun storiesWithLocation(
        @Query("location") id: Int
    ): ListResponse

    @GET("stories/{id}")
    suspend fun storyDetail(
        @Path("id") id: String
    ): DetailResponse

    @Multipart
    @POST("stories")
    suspend fun addStory(
        @Part file: MultipartBody.Part,
        @Part("description") description: RequestBody,
        @Part("lat") lat: Float?,
        @Part("lon") lon: Float?
    ): RegisterResponse
}