package com.dicoding.dicodingstory.Paging

import androidx.paging.ExperimentalPagingApi
import androidx.paging.LoadType
import androidx.paging.PagingState
import androidx.paging.RemoteMediator
import androidx.room.withTransaction
import com.dicoding.dicodingstory.API.ApiService
import com.dicoding.dicodingstory.response.StoryResponse


@OptIn(ExperimentalPagingApi::class)
class StoryRemoteMediator(private val storyPagingDatabase: StoryPagingDatabase,
                          private val apiService: ApiService
                          ): RemoteMediator<Int, StoryResponse>() {

    override suspend fun initialize(): InitializeAction {
        return InitializeAction.LAUNCH_INITIAL_REFRESH
    }

    override suspend fun load(
        loadType: LoadType,
        state: PagingState<Int, StoryResponse>
    ): MediatorResult {
        val page = when(loadType) {
            LoadType.REFRESH -> {
                val remoteKeys = getRemoteKeyClosectToCurrent(state)
                remoteKeys?.nextKey?.minus(1) ?: INITIAL_PAGE_INDEX
            }

            LoadType.PREPEND -> {
                val remoteKeys = getRemoteKeyForFirstTime(state)
                val prefKeys = remoteKeys?.prefKey ?: return MediatorResult.Success(endOfPaginationReached = remoteKeys != null)
                prefKeys
            }

            LoadType.APPEND -> {
                val remoteKeys = getRemoteKeyForLastItem(state)
                val nextKeys = remoteKeys?.nextKey ?: return MediatorResult.Success(endOfPaginationReached = remoteKeys != null)
                nextKeys
            }
        }

        return try {
            val responseData = apiService.stories(page, state.config.pageSize)
            val endOfPaginationReached = responseData.listStory.isEmpty()
            storyPagingDatabase.withTransaction {
                if (loadType == LoadType.REFRESH) {
                    storyPagingDatabase.StoryPagingsDao().deleteAllStory()
                    storyPagingDatabase.keysDao().deleteKeys()
                }
                val prevKey = if (page == 1) null else page -1
                val nextKey = if (endOfPaginationReached) null else page +1
                val keys = responseData.listStory.map {
                    RemoteKeys(id = it.id, prefKey = prevKey, nextKey = nextKey)
                }
                storyPagingDatabase.keysDao().insertAll(keys)
                storyPagingDatabase.StoryPagingsDao().insertStory(responseData.listStory)
            }
            MediatorResult.Success(endOfPaginationReached = endOfPaginationReached)
        } catch (e: Exception) {
            MediatorResult.Error(e)
        }
    }

    private suspend fun getRemoteKeyForLastItem(state: PagingState<Int, StoryResponse>): RemoteKeys? {
        return state.pages.lastOrNull { it.data.isNotEmpty() }?.data?.lastOrNull()?.let { data ->
           storyPagingDatabase.keysDao().getKeysId(data.id)
        }
    }

    private suspend fun getRemoteKeyForFirstTime(state: PagingState<Int, StoryResponse>): RemoteKeys? {
       return state.pages.firstOrNull { it.data.isNotEmpty() }?.data?.firstOrNull()?.let { data ->
           storyPagingDatabase.keysDao().getKeysId(data.id)
       }
    }

    private suspend fun getRemoteKeyClosectToCurrent(state: PagingState<Int, StoryResponse>): RemoteKeys? {
        return state.anchorPosition?.let { position ->
            state.closestItemToPosition(position)?.id?.let { id ->
                storyPagingDatabase.keysDao().getKeysId(id)
            }
        }
    }

    private companion object {
        const val INITIAL_PAGE_INDEX = 1
    }
}