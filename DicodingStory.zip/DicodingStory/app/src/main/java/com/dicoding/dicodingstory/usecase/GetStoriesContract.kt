package com.dicoding.dicodingstory.usecase

import androidx.paging.PagingData
import com.dicoding.dicodingstory.entity.StoryEntity
import com.dicoding.dicodingstory.response.StoryResponse
import kotlinx.coroutines.flow.Flow

interface GetStoriesContract {
    operator fun invoke(): Flow<PagingData<StoryResponse>>
}