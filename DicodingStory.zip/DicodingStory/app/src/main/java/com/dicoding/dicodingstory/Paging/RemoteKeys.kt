package com.dicoding.dicodingstory.Paging

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "keys")
data class RemoteKeys (
    @PrimaryKey val id: String,
    val prefKey: Int?,
    val nextKey: Int?
        )