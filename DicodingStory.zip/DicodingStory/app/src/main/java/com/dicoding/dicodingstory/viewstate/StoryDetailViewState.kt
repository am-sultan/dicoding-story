package com.dicoding.dicodingstory.viewstate

import com.dicoding.dicodingstory.entity.StoryEntity
import com.dicoding.dicodingstory.utility.ResultState

data class StoryDetailViewState(
    val resultStory: ResultState<StoryEntity> = ResultState.Idle()
)
