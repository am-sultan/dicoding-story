package com.dicoding.dicodingstory.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.dicoding.dicodingstory.Locator
import com.dicoding.dicodingstory.R
import com.dicoding.dicodingstory.databinding.ActivityRegisterBinding
import com.dicoding.dicodingstory.utility.ResultState
import com.dicoding.dicodingstory.utility.launchAndCollectIn
import com.dicoding.dicodingstory.viewmodel.RegisterViewModel

class RegisterActivity : AppCompatActivity() {

    private lateinit var registerBinding: ActivityRegisterBinding
    private val viewModel by viewModels<RegisterViewModel>(factoryProducer = {Locator.registerViewModelFactory})

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registerBinding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(registerBinding.root)

        registerStart()
        viewModel.registerViewState.launchAndCollectIn(this) {
         when (it.resultRegisterUser) {
             is ResultState.Success<String> -> {
                 showLoading(false)
                     Toast.makeText(this@RegisterActivity,getString(R.string.register_success),Toast.LENGTH_SHORT).show()
                     startActivity(Intent(this@RegisterActivity,LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                     finish()
             }
             is ResultState.Loading -> showLoading(true)
             is ResultState.Error ->  {
                 showLoading(false)
                 Toast.makeText(this@RegisterActivity, it.resultRegisterUser.message, Toast.LENGTH_SHORT).show()
             }
             else -> Unit
          }
        }

        registerBinding.btnRegister.setOnClickListener{

            viewModel.registerUser(
                name = registerBinding.edtRegisterName.text.toString(),
                email = registerBinding.edtRegisterEmail.text.toString(),
                password = registerBinding.edtRegisterPassword.text.toString()
            )
        }

        registerBinding.tvLogin.setOnClickListener{
            startActivity(Intent(this,LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            finish()
        }

        registerBinding.edtRegisterPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                registerStart()
            }
            override fun afterTextChanged(s: Editable) {
            }
        })
    }

    private fun registerStart() {
        val validPassword = registerBinding.edtRegisterPassword.text.toString()
        registerBinding.btnRegister.isEnabled = !TextUtils.isEmpty(validPassword) && validPassword.length >= 8
    }

    private fun showLoading(isLoading: Boolean) {
        registerBinding.progressBarRegister.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}