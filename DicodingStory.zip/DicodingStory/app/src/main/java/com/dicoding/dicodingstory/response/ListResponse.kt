package com.dicoding.dicodingstory.response

data class ListResponse (
    var error: Boolean,
    val message: String,
    val listStory: List<StoryResponse>
    )