package com.dicoding.dicodingstory.usecase

import com.dicoding.dicodingstory.Paging.map
import com.dicoding.dicodingstory.repository.StoryRepository
import kotlinx.coroutines.flow.*

class GetStoriesCase(private val storyRepository: StoryRepository):GetStoriesContract {
     override operator fun invoke() = storyRepository.getStories().map{ pagingData ->
      pagingData.map()
    }
}

