package com.dicoding.dicodingstory

import android.app.Application

class App: Application() {
    override fun onCreate() {
        super.onCreate()
        Locator.initWith(this)
    }
}