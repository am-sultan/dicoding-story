package com.dicoding.dicodingstory.usecase

import com.dicoding.dicodingstory.repository.UserPreferenceRepository

class LogoutUseCase(private val userPreferenceRepository: UserPreferenceRepository): LogoutUseContract {
    override suspend operator fun invoke() {
        userPreferenceRepository.clearUser()
    }
}
